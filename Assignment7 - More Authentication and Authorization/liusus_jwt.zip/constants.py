clientID = "499938882837-c6rurjceojlncsj010vfsph7d6aoaukq.apps.googleusercontent.com"
clientSecret = "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"
redirectURL = "http://127.0.0.1:8080/oauth"
boat = "boats"

# http://127.0.0.1:8080/
# https://working-joinin.uw.r.appspot.com/